

## About Employee API

This app is powered by laravel sanctum using Bearer Token,
This app has 2 roles admin and employee
This application is used to manage employee leave balance

